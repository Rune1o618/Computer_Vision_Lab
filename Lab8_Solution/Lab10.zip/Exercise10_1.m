function PartBasedModelExercise()

% Facial images are taken from the Calctech101 "Faces" folder.
% The complete Caltech101 database can be downloaded here:
% http://www.vision.caltech.edu/Image_Datasets/Caltech101/Caltech101.html
root_dir = pwd;
image_dir = 'Exercise1_images';
cd(image_dir)
files = dir('*.jpg');

global imgsz;
imgsz           = [200 200];
patchsz         = 30;
col             = 'bgrkc';
train_ix        = 1:20:length(files);
test_ix         = 3:20:length(files);

part_names{1}   = 'right eye';
part_names{2}   = 'left eye';
part_names{3}   = 'nose tip';
part_names{4}   = 'right mouth';
part_names{5}   = 'left mouth';

num_parts       = length(part_names);
ref_part        = 3; % Reference part = nose tip

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Training
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Task 1:
% Manually mark parts - store in my_parts.mat to avoid having to do this
% over and over...
figure
if not(exist([root_dir '\my_parts.mat']))    
    for train = 1:length(train_ix)
        % Load training image and display it
        I = loadimage(files(train_ix(train)).name);
        subplot(1,length(train_ix),train)
        imshow(I);
        title(['Training image ' num2str(train)])
        
        % Loop through parts - mark the spatial position of each part using the
        % mouse in this order:
        % Right eye, Left eye, Nose tip, Right mouth, Left mouth
        for part = 1:num_parts
            display(['Mark ' part_names{part}]);
            
            % Get coordinate of mouse click
            [x(part,train),y(part,train),b] = ginput(1);
            
            % Draw rectangle for this part
            rect = [x(part,train)-patchsz/2
                y(part,train)-patchsz/2
                patchsz-1
                patchsz-1];
            rectangle('Position',rect,'EdgeColor',col(part));
        end
    end
    save([root_dir '\my_parts.mat'],'x','y'); % Store
else
    load([root_dir '\my_parts.mat']);
    figure
    for train = 1:length(train_ix)
        I = loadimage(files(train_ix(train)).name);
        subplot(1,length(train_ix),train)
        imshow(I);
        for part = 1:num_parts
            rect = [x(part,train)-patchsz/2
                y(part,train)-patchsz/2
                patchsz-1
                patchsz-1];
            rectangle('Position',rect,'EdgeColor',col(part));
        end
    end
 
end

% Get patches and average over training images
figure
% Loop over parts
for part = 1:num_parts
    
    % Loop over training images and crop the corresponding image patch
    for train = 1:length(train_ix)
        I = loadimage(files(train_ix(train)).name);
        rect = [x(part,train)-patchsz/2
            y(part,train)-patchsz/2
            patchsz-1
            patchsz-1];
        patch(:,:,train) = imcrop(I,rect);
    end
    
    % TASK 2:
    % Calculate average/mean patch for the current part
    part_patch(:,:,part) = rand(patchsz,patchsz); % REPLACE!!!
    
    % Display average patch
    subplot(1,num_parts,part)
    imshow(part_patch(:,:,part));
    title(['Average ' part_names{part}])
end

% Plot positions of parts relative to reference part (nose tip).
% Also calculate and display the average position of each part relative to the
% reference (nose tip).
figure
hold on
for part = 1:num_parts
    pos_x = x(part,:)-x(ref_part,:);        % Relative x coordinate
    pos_y = -(y(part,:)-y(ref_part,:));     % Relative y coordinate
    
    % TASK 3:
    % Calculate average part position
    part_pos(1,part) = randn(1); % x coordinate (REPLACE!!!)
    part_pos(2,part) = randn(1); % x coordinate (REPLACE!!!)
    
    % Display
    plot(pos_x,pos_y,[ col(part) '.'],part_pos(1,part),part_pos(2,part),[ col(part) 'o'])
end
hold off
title('Part positions relative to nose')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Test
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loop over test images
for test = 1:length(test_ix)

    I = loadimage(files(test_ix(test)).name);
        
    % Do normalized cross-correlation for each part using the average part
    % patch as the template.
    figure
    for part = 1:num_parts
        cc_tmp = normxcorr2(part_patch(:,:,part),I); % Normalized cross-correlation
        cc(:,:,part) = cc_tmp((1:imgsz(1))+patchsz/2-1,(1:imgsz(2))+patchsz/2-1); % Crop result
        subplot(1,num_parts,part);
        imagesc(cc(:,:,part))
        axis equal
        title(['NCC ' part_names{part}])
    end
    
    % TASK 4
    % Figure out what is going on here and why
    figure
    for part = 1:num_parts
        x_shift = round(part_pos(2,part));
        y_shift = -round(part_pos(1,part));
        T = maketform('affine',[1 0 0; 0 1 0; -part_pos(1,part) part_pos(2,part) 1]);
        cc_shift(:,:,part) = imtransform(cc(:,:,part),T,'XData',[1 imgsz(1)],'YData',[1 imgsz(2)]);
        
        % Display
        subplot(1,num_parts,part);
        imagesc(cc_shift(:,:,part))
        axis equal
        title(['Shifted NCC ' part_names{part}])
    end
        
    % Total score = sum of shifted NCC maps
    total_score = sum(cc_shift,3);
    total_score(1:patchsz,:) = 0;
    total_score(:,1:patchsz) = 0;
    total_score(imgsz-patchsz+1:imgsz,:) = 0;
    total_score(:,imgsz-patchsz+1:imgsz) = 0;
    
    % Apply smoothing filter
    h = fspecial('gaussian',[10 10],5);     % Smooothing filter
    total_score = imfilter(total_score,h,'same');
    
    % Find max peak (=predicted position of nose tip)
    maxix = find(total_score == max(total_score(:)));
    [maxi,maxj] = ind2sub([imgsz imgsz],maxix);
    
    figure
    imagesc(total_score/num_parts)
    hold on
    plot(maxj,maxi,'o')
    hold off
    title('Summed NCC map + maximum peak')
    
    % Display result
    figure
    imshow(I)
    hold on
    plot(maxj,maxi,'o')
    hold off
    rect = [maxj-patchsz
            maxi-patchsz*3/2
            2*patchsz-1
            3*patchsz-1];
    rectangle('Position',rect,'EdgeColor','r');
    
    pause
    close all
end

function I = loadimage(name)
global imgsz;
I = imread(name);
I = rgb2gray(I);
I = double(I);
I = I/max(I(:));
I = imresize(I,imgsz,'bilinear');
