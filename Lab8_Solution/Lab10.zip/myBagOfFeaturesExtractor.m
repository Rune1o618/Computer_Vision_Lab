function [features, featureMetrics, varargout] = myBagOfFeaturesExtractor(I)

%% Step 1: Preprocess the Image
% The extractor function is applied to each image, I, within the image set
% used to create the bagOfFeatures. Depending on the type of features being
% extracted, the input images may require preprocessing prior to feature
% extraction. For SURF features, I must be a grayscale image.

% Convert I to grayscale if required.
[height,width,numChannels] = size(I);
if numChannels > 1
    grayImage = single(rgb2gray(I));
else
    grayImage = single(I);
end

%% Step 2: Extract features
% Finally, extract features from the selected point locations.
gridSize = 16; % grid size and spacing as in slide 9


% Exercise: implement dense SIFT on the image 'grayImage' and assign the 
% SIFT descriptors to the variable 'features'. 'features' must be a 
% (NumberOfPoints x 128) matrix.
% Start with a single scale (e.g. 3.2). When this is working, add other 
% scales (e.g. 1.6 and 4.8) by concatenating the �features� matrix and look
% at the improvement in classification accuracy.
% Hint: find inspiration on http://www.vlfeat.org/matlab/vl_dsift.html and
% use the parameters 'size' and 'step' equal to 'gridSize' defined above.

features = 1; % Change this




% Convert to single data type
features = single(features);

%% Step 3: Compute the Feature Metric
% The feature metrics indicate the strength of each feature, where larger
% metric values are given to stronger features. The feature metrics are
% used to remove weak features before bagOfFeatures learns a visual
% vocabulary. You may use any metric that is suitable for your feature
% vectors.
%
% Use the variance of the SURF features as the feature metric.
featureMetrics = var(features,[],2);


