function J = warp_to_mean_shape(TrainingData,ShapeData,options)
% Make the gray-level Appearance Model

% Coordinates of mean contour
base_points = [ShapeData.x_mean(1:end/2) ShapeData.x_mean(end/2+1:end)];

% Normalize the base points to range 0..1
base_points = base_points - repmat(min(base_points),size(base_points,1),1);
base_points = base_points ./ repmat(max(base_points),size(base_points,1),1);

% Transform the mean contour points into the coordinates in the texture
% image.
base_points(:,1)=1+(ShapeData.TextureSize(1)-1)*base_points(:,1);
base_points(:,2)=1+(ShapeData.TextureSize(2)-1)*base_points(:,2);

% Draw the contour as one closed line white line and fill the resulting
% (hand) object
ObjectPixels= drawObject(base_points,ShapeData.TextureSize,TrainingData(1).Lines);
ObjectPixels=bwconvhull(ObjectPixels);

% Number of datasets
s=length(TrainingData);


% Transform the hands images first into the mean texture image, and than
% transform the image into a vector using the pixellocations of the object
% found here above.

% Construct a matrix with all appearance data of the training data set
npixels=sum(ObjectPixels(:));
I = TrainingData(1).I;
g=zeros(npixels*size(I,3),s);
for i=1:s
    
    I = double(TrainingData(i).I);
    g(:,i)=AAM_Appearance2Vector2D(I,TrainingData(i).Vertices, base_points, ObjectPixels,ShapeData.TextureSize,ShapeData.Tri);
    J_RGB=AAM_Vector2Appearance2D(g(:,i),ObjectPixels,ShapeData.TextureSize);
    J(:,:,i) = rgb2gray(J_RGB);
    subplot(1,2,1),imshow(I)
    hold on
    plot(TrainingData(i).Vertices(:,2),TrainingData(i).Vertices(:,1),'.')
    hold off
    title('Input image')
    subplot(1,2,2),imshow(J(:,:,i))
    title('Warped to mean shape')
    drawnow
end


