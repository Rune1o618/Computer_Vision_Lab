clear all;

RootDir = pwd;

AAM_DIR = 'ActiveModels_version7';
addpath(genpath(AAM_DIR));

ImageDir = 'Exercise2_images';
addpath(genpath(ImageDir));

% Convert facial landmarks into format expected by the AAM toolbox
cd(ImageDir);
jpg_files = dir('*.jpg');
for i = 1:length(jpg_files)
    i
    landmarks = load([jpg_files(i).name(1:end-4) '.mat']);
    p.y = landmarks.ypos;
    p.x = landmarks.xpos;
    p.n = 66;
    p.t = zeros(1,66);
    p.image = jpg_files(i).name;
    save(['dat' num2str(i) '.mat'],'p');
end

%% Set options
% Number of contour points interpolated between the major landmarks.
options.ni=2;
% Set normal appearance/contour, limit to +- m*sqrt( eigenvalue )
options.m=3;
% Size of appearance texture as amount of orignal image
options.texturesize=1;
% If verbose is true all debug images will be shown.
options.verbose=true;
% Number of image scales
options.nscales=4;
% Number of search itterations
options.nsearch=15;

%% Load training data (Contour and Image)
% The LoadDataSetNiceContour, not only reads the contour points, but
% also resamples them to get a nice uniform spacing, between the important
% landmark contour points.
cd(RootDir);
TrainingData=struct;
if options.verbose, figure(1); end
for i=1:length(jpg_files)
    filename=['dat' num2str(i) '.mat'];
    load(filename);
    [TrainingData(i).Vertices, TrainingData(i).Lines]=LoadDataSetNiceContour(filename,options.ni,0);
    
    I=double(imread(p.image))/255;
    if (options.verbose)        
        Vertices=TrainingData(i).Vertices;
        imshow(I); hold on;
        plot(Vertices(:,2),Vertices(:,1),'.b');
        hold off
        drawnow;
    end
    TrainingData(i).image = p.image;
    TrainingData(i).I = I;
end

%% Shape Model %%
% Make the Shape model, which finds the variations between contours
% in the training data sets. And makes a PCA model describing normal
% contours
[ShapeData,TrainingData] = AAM_MakeShapeModel2D(TrainingData,options);
    
% Coordinates of mean contour
base_points = [ShapeData.x_mean(1:end/2) ShapeData.x_mean(end/2+1:end)];

% Normalize the base points to range 0..1
base_points = base_points - repmat(min(base_points),size(base_points,1),1);
base_points = base_points ./ repmat(max(base_points),size(base_points,1),1);

% Transform the mean contour points into the coordinates in the texture
% image.
base_points(:,1)=1+(ShapeData.TextureSize(1)-1)*base_points(:,1);
base_points(:,2)=1+(ShapeData.TextureSize(2)-1)*base_points(:,2);

% Draw the contour as one closed line white line and fill the resulting
% (hand) object
ObjectPixels= drawObject(base_points,ShapeData.TextureSize,TrainingData(1).Lines);
ObjectPixels= bwconvhull(ObjectPixels);

% Show some eigenvector variations
if(options.verbose)
    figure(2)
    for i=1:10
        s=sqrt(ShapeData.Evalues(i))*2;
        range = linspace(-s,s,50);
        range = [ range fliplr(range) ];
        for j = 1:length(range)
            xtest = ShapeData.x_mean + ShapeData.Evectors(:,i)*range(j);
            plot(xtest(end/2+1:end),-xtest(1:end/2),'r.-',...
                ShapeData.x_mean(end/2+1:end),-ShapeData.x_mean(1:end/2),'b.-');
            axis([-80    100   -100    80 ])
            title(['Principal component: ' num2str(i)])
            drawnow
        end
    end
end

% TASK 1:
% Figure 3 shows the landmarks from first five training images
% before and after Procrustes alignment. What is the difference between the
% landmarks before and after? 
figure(3)
for i=1:5
    subplot(1,2,1),
    hold on
    plot(TrainingData(i).Vertices(:,2),-TrainingData(i).Vertices(:,1))
    hold off
    axis equal
    title('Before Procrustes')
    subplot(1,2,2),
    hold on
    plot(TrainingData(i).CVertices(:,2),-TrainingData(i).CVertices(:,1))
    hold off
    axis equal
    title('After Procrustes')
end

%% Warp training images to mean shape
figure(4)
J = hpe_warp_to_mean_shape(TrainingData,ShapeData,options);

% TASK 2:
% Do PCA on the aligned textures (variable J).
% See AAM_MakeShapeModel2D.m for inspiration
[Evalues, Evectors, J_mean] = %???

% Show some eigenvector variations
if(options.verbose)
    figure(5)
    for i=1:5
        s=sqrt(Evalues(i))*2;
        range = linspace(-s,s,20);
        range = [ range fliplr(range) ];
        for j = 1:length(range)
            Jtest = J_mean + Evectors(:,i)*range(j);
            imshow(reshape(Jtest,size(J(:,:,1))))
            title(['Principal component: ' num2str(i)])
            drawnow
        end
    end
end

%% Support Vector Machine (SVM) classification using spatial landmarks as input
xdata = ShapeData.x;
xdata = xdata';

% Get labels
cd(ImageDir);
jpg_files = dir('*.jpg');
for i = 1:length(jpg_files)
    k = strfind(jpg_files(i).name, 'nopain');
    if k == 1
        label{i} = 'No pain';
    else
        label{i} = 'Pain';
    end
end
cd(RootDir);

% SVM training
ix = randperm(200);
train_ix = ix(1:180);
test_ix = ix(181:200);
svmStruct = svmtrain(xdata(train_ix,:),label(train_ix));

% SVM test
label_pred = svmclassify(svmStruct,xdata(test_ix,:));

% Display correct vs. predicted labels (Correct/Predicted)
figure(6)
for k = 1:length(test_ix)
    i = test_ix(k);
    subplot(4,5,k)
    imshow(TrainingData(i).I)
    title([label{i} '/' label_pred{k}])
end

% Task 3:
% SVM classification using texture as input
Jdata = %???

% SVM training
svmStruct_tex = svmtrain(Jdata(train_ix,:),label(train_ix));

% SVM test
label_pred_tex = svmclassify(svmStruct_tex,Jdata(test_ix,:));

% Display correct vs. predicted labels (Correct/Predicted)
figure(7)
for k = 1:length(test_ix)
    i = test_ix(k);
    subplot(4,5,k)
    imshow(TrainingData(i).I)
    title([label{i} '/' label_pred_tex{k}])
end
